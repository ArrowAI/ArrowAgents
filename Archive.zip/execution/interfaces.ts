export interface IContext {
    pastValues: [];
}

export type FlowJson= {
    nodes: IntegrationInterface[]
}