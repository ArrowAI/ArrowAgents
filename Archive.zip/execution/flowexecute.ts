import {FlowExecutorObject}
export class FlowExecuteHandler {
    db: DB;
    constructor(){
        this.db = new DB();
    }
   
    getCurrentNode(nodes: IntegrationInterface[]) {
        const currentNode = nodes[0]; // filter current node from nodes
        return currentNode;
    } 
    execute(FlowExecutorObject: FlowExecutorObject) {
        const flow: FlowJson = this.db.getFlow(flowId);   
        const nodes: IntegrationInterface[] = flow.nodes;
        const currentNode = this.getCurrentNode(nodes);
        const actionExecutor = this.db.getActionExecutor(currentNode);
        // get executon Type from environment variable
        return actionExecutor.execute(currentNode.actionId,ExecutionType.local);
        
    }
}