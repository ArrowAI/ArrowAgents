import { flowExecutorStore } from "./flowexecutorstore";
import {FlowExecuteHandler } from "../execution/flowexecute"

export class Engine{
    ArrowFlowExecutorStore: flowExecutorStore;
    constructor(){
        this.ArrowFlowExecutorStore = new flowExecutorStore();
    }
    execute(flowId: string){
        let flowExecutor = this.ArrowFlowExecutorStore.findFlowExecutor(flowId);
        FlowExecuteHandler.execute(flowId);
    }

    //This is the Function that is called every minute, so that it can check for triggers and any delay functions
    executeStep(){
        
    }
}