//Run the Cron for every minute.
import { CronJob } from 'cron';
import { Engine } from '../engine/engine';

export class CronService {
    engine: Engine;
    constructor(Engine: Engine) {
        this.engine = Engine;
    }
    start(){
        new CronJob('*/1 * * * * *', () => {
            this.engine.executeStep();
        }).start();
    }
}